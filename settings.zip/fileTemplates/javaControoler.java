import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("${NAME}")
public class ${NAME} {

    @RequestMapping("test")
    public void test() {
    
    }
}
